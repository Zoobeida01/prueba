-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: logistica_covid
-- ------------------------------------------------------
-- Server version	5.7.36-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cRecursoTipos`
--

DROP TABLE IF EXISTS `cRecursoTipos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cRecursoTipos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipoRecurso` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cRecursoTipos`
--

LOCK TABLES `cRecursoTipos` WRITE;
/*!40000 ALTER TABLE `cRecursoTipos` DISABLE KEYS */;
INSERT INTO `cRecursoTipos` VALUES (1,'Carpas de triage respiratorio'),(2,'Cama en piso de hospitalización censable'),(3,'Consultorios generales'),(4,'Consultorios especializados'),(5,'Carros de paro'),(6,'Laboratorio clínico'),(7,'Laboratorio de microbiología'),(8,'Banco de sangre'),(9,'Rayos X'),(10,'Rayos X portátil'),(11,'Tomografía computarizada'),(12,'Ultrasonidos en hospital'),(13,'Ultrasonidos en urgencias'),(14,'Ultrasonidos en UCI'),(15,'Electrocardiogramas'),(16,'Electrocardiogramas en Urgencias'),(17,'Electrocardiogramas en UCI'),(18,'Broncoscopios'),(19,'Bombas de Infusión'),(20,'Monitores portátitles signos vitales'),(21,'Equipos para hemodiálisis'),(22,'Ventiladores'),(23,'Camas de adulto en UCI'),(24,'Camas pediátricas en UCI'),(25,'UCI Neonatales'),(26,'Camas en terapia intermedia'),(27,'Hospitalizacion de pacientes con COVID-19'),(28,'Camas no censables'),(29,'Camas IRAG disponibles sin ventilador'),(30,'Camas IRAG disponibles con ventilador'),(31,'Camas IRAG disponibles en UCI'),(32,'Ventiladores disponibles de respaldo');
/*!40000 ALTER TABLE `cRecursoTipos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-27 14:26:54
