-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: logistica_covid
-- ------------------------------------------------------
-- Server version	5.7.36-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tHospitales`
--

DROP TABLE IF EXISTS `tHospitales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tHospitales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) DEFAULT NULL,
  `nombre_corto` varchar(100) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `atiende_covid19` int(1) DEFAULT '0',
  `clues` varchar(45) DEFAULT NULL,
  `cp` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tHospitales`
--

LOCK TABLES `tHospitales` WRITE;
/*!40000 ALTER TABLE `tHospitales` DISABLE KEYS */;
INSERT INTO `tHospitales` VALUES (1,'HOSPITAL DE ESPECIALIDADES DE LA CIUDAD DE MEXICO DR. BELISARIO DOMINGUEZ','HE Dr. Belisario D','Av. Tlahuac 4866, Col. San Lorenzo Tezonco. Iztapalapa',1,'DFSSA004265','9790'),(2,'HOSPITAL GENERAL DR. ENRIQUE CABRERA','HG Dr. Enrique Cabrera','Avenida Prolongación 5 de Mayo y esq. Centenario Colonia Ex-Hacienda de Tarango, Álvaro Obregón',1,'DFSSA017886','1620'),(3,'HOSPITAL GENERAL DR. RUBEN LEÑERO','HG Dr. Ruben Leñero','Plan de San Luis Esq. Salvador Díaz Mirón S/N, Col. Santo Tomás. Miguel Hidalgo',0,'DFSSA003553','11340'),(4,'HOSPITAL GENERAL XOCO','HG Xoco','Avenida Cuauhtémoc esq. Bruno Trave s/n Colonia Xoco, Benito Juárez',0,'DFSSA003162','3330'),(5,'HOSPITAL GENERAL VILLA','HG Villa','Av. San Antonio No.285, Col. Granjas de San Antonio. Gustavo A. Madero',0,'DFSSA000881','7460'),(6,'HOSPITAL GENERAL BALBUENA','HG Balbuena','Cecilio Robelo y Sur 103, Col. Aeronáutica Militar. Venustiano Carranza',0,'DFSSA003722','15970'),(7,'HOSPITAL GENERAL DR. GREGORIO SALAS FLORES','HG Dr. Gregorio Salas Flores','Del Carmen #42 Col. Centro Delegación Cuauhtémoc',0,'DFSSA003384','6020'),(8,'HOSPITAL GENERAL IZTAPALAPA','HG Iztapalapa','Av. Ermita Iztapalapa #3018 Col. Citlalli, Delegación Iztapalapa',0,'DFSSA001540','9660'),(9,'HOSPITAL GENERAL MILPA ALTA','HG Milpa Alta','Boulevard Nuevo León #386, Col. Villa Milpa Alta, Delegación Milpa Alta',0,'DFSSA002066','1200'),(10,'HOSPITAL GENERAL TICOMAN','HG Ticoman','Plan de San Luís s/n Col. Ticomán, Delegación Gustavo A. Madero',0,'DFSSA000864','7330'),(11,'HOSPITAL GENERAL TLAHUAC','HG Tlahuac','Av. La Turba No. 655 Col. Villa Centroamericana y del Caribe, Delegación Tláhuac',1,'DFSSA018154','13278'),(12,'HOSPITAL GENERAL AJUSCO MEDIO','HG Ajusco Medio','Encinos # 41 Ampliación Miguel Hidalgo 4ta Sección, Delegación Tlalpan',0,'DFSSA018166','14250'),(13,'CLINICA HOSPITAL EMILIANO ZAPATA','CH Emiliano Zapata','Calle Cuco Sánchez no. 71 Col. Ampliación Emiliano Zapata Delegación Iztapalapa;9638\n14;HOSPITAL PEDIATRICO AZCAPOTZALCO;DFSSA000053;Av. Azcapotzalco # 731 Col. Azcapotzalco, Delegación Azcapotzalco\"',0,'DFSSA018142','3000'),(14,'HOSPITAL PEDIATRICO AZCAPOTZALCO','HP Azcapotzalco','Av. Azcapotzalco # 731 Col. Azcapotzalco, Delegación Azcapotzalco',0,'DFSSA000053','3000'),(15,'HOSPITAL PEDIATRICO COYOACAN','HP Coyoacan','Moctezuma #18, Col. Del Carmen, Delegación Coyoacán',0,'DFSSA000350','831'),(16,'HOSPITAL PEDIATRICO VILLA','HP Villa','Av. Cantera  esq. Hidalgo s/n, Col. Estanzuela Delegación Gustavo A. Madero',1,'DFSSA000840','7050'),(17,'HOSPITAL PEDIATRICO LEGARIA','HP Legaria','Calzada Legaria #371, Col. Nuevo México Delegación Miguel Hidalgo',0,'DFSSA003541','11260'),(18,'HOSPITAL PEDIATRICO IZTACALCO','HP Iztacalco','Av. Coyuya y Terraplén de Río Frío s/n Col. La Cruz, Delegación Iztacalco',0,'DFSSA001296','11260'),(19,'HOSPITAL PEDIATRICO IZTAPALAPA','HP Iztapalapa','Calzada Ermita Iztapalapa #780, Col. Granjas San Antonio, Delegación Iztapalapa',0,'DFSSA001511','9070'),(20,'HOSPITAL PEDIATRICO MOCTEZUMA','HP Moctezuma','Oriente 170 No. 154 Esq. 4a Cerrada de Oriente 168, Col. Moctezuma 2° Sección',0,'DFSSA003710','15500'),(21,'HOSPITAL PEDIATRICO PERALVILLO','HP Peralvillo','Tolnahuac # 14, Col. San Simón Tolnahuac, Delegación Cuauhtémoc',0,'DFSSA003372','6920'),(22,'HOSPITAL PEDIATRICO SAN JUAN DE ARAGON','HP San Juan De Aragon','Av.  506 entre Calle 517 y 521 Col. San Juan de Aragón 1ª Sección, Delegación Gustavo',0,'DFSSA000835','7969'),(23,'HOSPITAL PEDIATRICO TACUBAYA','HP Tacubaya','Calle Carlos Lazo #25 Esq. Gaviota, Col. Tacubaya, Delegación Miguel Hidalgo',0,'DFSSA003536','11870'),(24,'HOSPITAL MATERNO INFANTIL INGUARAN','HM Infantil Inguaran','Estaño # 307 Esq. Congreso de la Unión, Col. Felipe Ángeles, Delegación Venustiano Carranza',0,'DFSSA003705','15310'),(25,'HOSPITAL MATERNO INFANTIL MAGDALENA CONTRERAS','HM Infantil Magdalena Contreras','Av. Luís Cabrera #619 Col. San Jerónimo Lidice, Delegación Magdalena Contreras',0,'DFSSA001926','10200'),(26,'HOSPITAL MATERNO INFANTIL CUAUTEPEC','HM Infantil Cuautepec','Emiliano Zapata # 17 Col. Cuautepec Barrio Bajo, Delegación Gustavo A. Madero',0,'DFSSA000852','7200'),(27,'HOSPITAL MATERNO INFANTIL TLAHUAC','HM Infantil Tlahuac','Av. Tláhuac Chalco #231 Col. La Habana Delegación Tláhuac',0,'DFSSA002491','13050'),(28,'HOSPITAL MATERNO INFANTIL DR. NICOLAS M. CEDILLO','HM Infantil Dr. Nicolas M. Cedillo','Gustavo J. S/n Esq. Víctor Hernández Covarrubias, Col. Unidad Francisco Villa, Delegación Azcapotzalco',0,'DFSSA000065','2400'),(29,'HOSPITAL MATERNO PEDIATRICO XOCHIMILCO','HM Pediatrico Xochimilco','Prolongación 16 de Septiembre y Calzada Nativitas Col. Barrio de Xaltocán Delegación Xochimilco',0,'DFSSA002993','16090'),(30,'HOSPITAL MATERNO INFANTIL TOPILEJO','HM Infaltil Topilejo',NULL,0,NULL,NULL),(31,'CLINICA HOSPITAL DE ESPECIALIDADES TOXICOLÓGICAS V. CARRANZA','CH Toxicológicas V. Carranza',NULL,0,NULL,NULL),(32,'CLINICA HOSPITAL DE ESPECIALIDADES TOXICOLÓGICAS XOCHIMILCO','CH Toxicológicas Xochimilco',NULL,0,NULL,NULL),(33,'Hospitales en Reclusorios','Hospitales En Reclusorios',NULL,0,NULL,NULL),(34,'UNIDAD MÉDICA TEMPORAL COVID 19','UM Temporal Covid 19',NULL,1,NULL,NULL),(35,'HOSPITAL GENERAL TORRE MEDICA TEPEPAN','HG Torre Medica Tepepan',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `tHospitales` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-27 14:24:42
