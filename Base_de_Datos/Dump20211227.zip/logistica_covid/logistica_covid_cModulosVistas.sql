-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: logistica_covid
-- ------------------------------------------------------
-- Server version	5.7.36-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cModulosVistas`
--

DROP TABLE IF EXISTS `cModulosVistas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cModulosVistas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uri` varchar(150) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `acciones` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cModulosVistas`
--

LOCK TABLES `cModulosVistas` WRITE;
/*!40000 ALTER TABLE `cModulosVistas` DISABLE KEYS */;
INSERT INTO `cModulosVistas` VALUES (1,'admin/catalogo/usuarios','Catálogo de Usuarios','ver,crear,editar'),(2,'admin/catalogo/roles','Catálogo de Roles','ver,crear,editar'),(3,'admin/catalogo/hospitales','Catálogo de Hospitales','ver,crear,editar'),(4,'admin/catalogo/antecedentes','Catálogo de Antecedentes','ver,crear,editar'),(5,'admin/catalogo/constantes_vitales','Catálogo de Constantes Vitales','ver,crear,editar'),(6,'admin/catalogo/estados_alerta','Catálogo de Estados Alerta','ver,crear,editar'),(7,'triage/registro/formulario','Triage Formulario','ver,crear'),(8,'admin/catalogo/sintomas','Catálogo de Sintomas','ver,crear,editar'),(9,'triage/registro/pacientes','Triage Pacientes Registrados','ver,descargar'),(10,'triage/registro/paciente_detalle','Triage Detalle de Paciente','ver'),(11,'triage/catalogo/antecedentes','Triage Antecedentes','ver,editar'),(12,'triage/catalogo/constantes_vitales','Triage Constantes Vitales','ver'),(13,'triage/catalogo/estados_alerta','Triage Estados Alerta','ver'),(14,'triage/catalogo/sintomas','Triage Sintomas','ver'),(15,'bi/dashboard/pacientes_atencion','Dashboard de Pacientes en Atención','ver'),(16,'admin/info/perfil','Información de Perfil','ver,editar'),(17,'admin/catalogo/especialidades','Catálogo de Especialidades','ver,crear,editar'),(18,'admin/registro/permisos','Control de Permisos Rol-Vista','ver,editar'),(19,'bi/dashboard/pacientes_alta','Dashboard de Pacientes dados de Alta','ver'),(20,'admin/catalogo/modulos_vistas','Catálogo de Módulos y Vistas','ver,editar'),(21,'etl/reporte/historico','ETL Reportes - Historico','ver'),(22,'etl/reporte/carga','ETL Reporte - Carga','ver'),(23,'de/terminos_medicos/get','Dashboard de Extracción de Términos','ver,descargar');
/*!40000 ALTER TABLE `cModulosVistas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-27 14:25:10
