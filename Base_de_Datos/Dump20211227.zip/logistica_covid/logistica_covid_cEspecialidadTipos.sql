-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: logistica_covid
-- ------------------------------------------------------
-- Server version	5.7.36-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cEspecialidadTipos`
--

DROP TABLE IF EXISTS `cEspecialidadTipos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cEspecialidadTipos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) DEFAULT NULL,
  `agrupar_en_otras` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cEspecialidadTipos`
--

LOCK TABLES `cEspecialidadTipos` WRITE;
/*!40000 ALTER TABLE `cEspecialidadTipos` DISABLE KEYS */;
INSERT INTO `cEspecialidadTipos` VALUES (1,'Medicina Interna',0),(2,'Cirugía General',0),(3,'Pediatría',1),(4,'Oftalmología',1),(5,'Gineco-obstetricia',1),(6,'Otorrinonaringología',1),(7,'Traumatología',1),(8,'Dermatología',1),(9,'Anestesiología',1),(10,'Psiquiatría',1),(12,'Endocrinología',1),(13,'Gastroenterología',1),(14,'Cardiología',1),(15,'Rehabilitación - Medicina física',1),(16,'Urología',1),(17,'Cirugía reconstructiva',1),(18,'Neumología',1),(19,'Neurología',1),(20,'Oncología',1),(21,'Hematología',1),(22,'Urgencias',0),(23,'Ortopedia',1),(24,'Proctología',1),(25,'Angiología',1),(26,'Nefrología',1),(27,'Reumatología',1),(28,'Infectología',1),(29,'Geriatría',1),(30,'Alergología',1),(31,'Genética médica',1),(32,'Radiología',1),(33,'Neonatología',1),(34,'Terapia Intermedia',1),(35,'Terapia Intensiva',1),(36,'Cirugía Pedíatrica',1),(37,'Traumatología y Ortopedia',1),(38,'B1',1),(39,'B2',1),(40,'B3',1),(41,'B4',1),(42,'UCIN',1),(43,'Quemados',1),(44,'Prescolares',1),(45,'Bariatría',1),(46,'Columna',1),(47,'Medicina Interna/Quemados',1),(48,'Lactantes',1),(49,'C7',1),(50,'C2',1),(51,'C5',1),(52,'C6',1);
/*!40000 ALTER TABLE `cEspecialidadTipos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-27 14:26:22
