-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: logistica_covid
-- ------------------------------------------------------
-- Server version	5.7.36-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tUsuarios`
--

DROP TABLE IF EXISTS `tUsuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tUsuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rol_id` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `apellido_paterno` varchar(50) DEFAULT NULL,
  `apellido_materno` varchar(50) DEFAULT NULL,
  `usuario` varchar(45) DEFAULT NULL,
  `contrasena` varchar(500) DEFAULT NULL,
  `hospital_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tUsuarios_usuario_uindex` (`usuario`),
  KEY `fk_tUsuarios_tHospitales` (`hospital_id`),
  KEY `fk_tUsuarios_cRoles_idx` (`rol_id`),
  CONSTRAINT `fk_tUsuarios_cRoles` FOREIGN KEY (`rol_id`) REFERENCES `cRoles` (`id`),
  CONSTRAINT `fk_tUsuarios_tHospitales` FOREIGN KEY (`hospital_id`) REFERENCES `tHospitales` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tUsuarios`
--

LOCK TABLES `tUsuarios` WRITE;
/*!40000 ALTER TABLE `tUsuarios` DISABLE KEYS */;
INSERT INTO `tUsuarios` VALUES (8,2,'SEDESA',NULL,NULL,'admin@sedesa.gob','gAAAAABfCOGacH2B1zB0TO1pUXYUfXHTHgR9ZFEELUv3u9v_V0lBUd01Gjx9-FkawY8br90R_v1hD2QPjkjcF_iUvqAiMyUGChjZtNWKcDQalwuUkANPcXp8ZhZJnIYIjhh30LNCCk5lCiZruPYC2gJMXj7aw1mVQxeFbRfRqY9T5R9VNi_7yRVy8s8KfFt8306vw5ZnPGoNlXOuzUKdyyNDfYYnynx2m7f6lB56yrEOeOu87XJjoj6wNjbwFH5OIQw7cSy4WBtE',NULL),(14,5,'HG ','ENRIQUE','CABRERA 1','hgecabrera1@sedesa.cdmx.gob.mx','gAAAAABfGcK9ZIf_TZIfSoa0l1IpCIWYuS-cqJybwj8CmmJLOotjh0r_FjXmnmOUbdhtiMFEc30PfodfEyCquiGxXKYffWyjJ1n6MI1w_wGNMQZuX_L8upSeeviHbpb3ZlNSuBlEoiM2OYCJA_UwXOxqjlwEaXSdLrRS6sLREotCCBD8qQgeQ07AE8LSw1Z67YF4Efys52GTz9pfO0B6l_4as72mUA-OaBOrGMr6lXMiOAGf6iXu0GqgSggsJQlCxH37lFHlAOc3',2),(15,5,'HG','ENRIQUE','CABRERA 2','hgecabrera2@sedesa.cdmx.gob.mx','gAAAAABfGcLkvs8oSFvcAMlzLYdrjejiNKEpG46Fq9dCOu4SttC1ThP_Z62YqvJ2RFtBHdULitylYwtcqjj0IYALYuduKnU_Qrbzoi5bWCrAsk8l51VRQnrQ842WPToZxocsJetJPa2-7BpnATqsN9Mbj8ZiUWtutgg7FrDbH0CCgMuxxQBn8_6A6NfrNqjqprfGM36sO4tWdZ0k0zZNoUEz7lVm0q5r_AxIyZU2CuLPZIVXKRn_CZh-KpKEi_QDG70xdxZ4gfOo',2),(16,5,'HG','ENRIQUE','CABRERA 3','hgecabrera3@sedesa.cdmx.gob.mx','gAAAAABfGcMHuW79x5KeXxeCD9D84G2z_YaJVjCXcTsI9QkzrM8ci1z5ofbp_7I8wYXGK5oYbKFi5eq17b1mWCbezM2ZZT_31cc2kDcJUYTheJnuErHTD3YZEQFgDd29vGi3QkxCr1yDoeamAvzGD4E29ehmAdjfQR47lxzgkLgxLbBlqR9ifKHfRvj7-5D9wQPr_I7rIEMnNzyzfycLAtCmjgAPzLbTXdfANyYIRk-TJj-OUyn_TCG8SbAl3Wjw57jzY92qtsha',2);
/*!40000 ALTER TABLE `tUsuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-27 14:25:45
