-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: logistica_covid
-- ------------------------------------------------------
-- Server version	5.7.36-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cEstadosAlertaOpciones`
--

DROP TABLE IF EXISTS `cEstadosAlertaOpciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cEstadosAlertaOpciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `estado_alerta_id` int(11) NOT NULL,
  `nombre` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cEstadosAlertaOpciones_id_uindex` (`id`),
  KEY `fk_cEstadosAlertaOpciones_cEstadosAlerta` (`estado_alerta_id`),
  CONSTRAINT `fk_cEstadosAlertaOpciones_cEstadosAlerta` FOREIGN KEY (`estado_alerta_id`) REFERENCES `cEstadosAlerta` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cEstadosAlertaOpciones`
--

LOCK TABLES `cEstadosAlertaOpciones` WRITE;
/*!40000 ALTER TABLE `cEstadosAlertaOpciones` DISABLE KEYS */;
INSERT INTO `cEstadosAlertaOpciones` VALUES (1,1,'Alerta'),(2,1,'Desorientado'),(3,2,'Espontánea'),(4,2,'Voz'),(5,2,'Dolor'),(6,2,'Ninguna'),(7,3,'Orientada'),(8,3,'Confusa'),(9,3,'Inapropiada'),(10,3,'Sonidos'),(11,3,'Ninguna'),(12,4,'Obedece'),(13,4,'Localiza'),(14,4,'Retirada'),(15,4,'Flexión'),(16,4,'Extensión'),(17,4,'Ninguna'),(18,5,'Con oxígeno'),(19,5,'Sin oxígeno');
/*!40000 ALTER TABLE `cEstadosAlertaOpciones` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-27 14:25:15
