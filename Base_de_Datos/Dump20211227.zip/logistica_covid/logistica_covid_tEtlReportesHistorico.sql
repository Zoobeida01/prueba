-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: logistica_covid
-- ------------------------------------------------------
-- Server version	5.7.36-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tEtlReportesHistorico`
--

DROP TABLE IF EXISTS `tEtlReportesHistorico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tEtlReportesHistorico` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(20) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `reporte` varchar(50) DEFAULT NULL,
  `log` varchar(26) DEFAULT NULL,
  `estatus` varchar(10) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  UNIQUE KEY `tEtlReportesHistorico_id_uindex` (`id`),
  KEY `tEtlReportesHistorico_tUsuarios_id_fk` (`usuario_id`),
  CONSTRAINT `tEtlReportesHistorico_tUsuarios_id_fk` FOREIGN KEY (`usuario_id`) REFERENCES `tUsuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tEtlReportesHistorico`
--

LOCK TABLES `tEtlReportesHistorico` WRITE;
/*!40000 ALTER TABLE `tEtlReportesHistorico` DISABLE KEYS */;
INSERT INTO `tEtlReportesHistorico` VALUES (1,'Ingresos','2020-08-02 06:06:20','Informe UNAM 30062020_corregido.xlsx','20200802_060435_093839.log','Exito',8),(2,'Ingresos','2020-08-02 06:36:30','Informe UNAM 23072020_corregido.xlsx','20200802_063453_470093.log','Exito',8),(3,'Ingresos','2020-10-14 18:07:03','Informe UNAM 07082020.xlsx','20201014_180459_472687.log','Exito',8),(4,'Ingresos','2020-10-14 19:38:00','Informe UNAM 31082020.xlsx','20201014_193519_539651.log','Exito',8);
/*!40000 ALTER TABLE `tEtlReportesHistorico` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-27 14:25:55
