-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: logistica_covid
-- ------------------------------------------------------
-- Server version	5.7.36-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tRecursoRegistros`
--

DROP TABLE IF EXISTS `tRecursoRegistros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tRecursoRegistros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tUsuarios_id` int(11) NOT NULL,
  `tHospitales_id` int(11) NOT NULL,
  `horaFecha` datetime DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `cRecursoTipos_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tRecursoRegistros_cRecursoTipos1_idx` (`cRecursoTipos_id`),
  KEY `fk_tRegistros_tHospitales1_idx` (`tHospitales_id`),
  KEY `fk_tRegistros_tUsuarios1_idx` (`tUsuarios_id`),
  CONSTRAINT `fk_tRecursoRegistros_cRecursoTipos1` FOREIGN KEY (`cRecursoTipos_id`) REFERENCES `cRecursoTipos` (`id`),
  CONSTRAINT `fk_tRegistros_tHospitales1` FOREIGN KEY (`tHospitales_id`) REFERENCES `tHospitales` (`id`),
  CONSTRAINT `fk_tRegistros_tUsuarios1` FOREIGN KEY (`tUsuarios_id`) REFERENCES `tUsuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tRecursoRegistros`
--

LOCK TABLES `tRecursoRegistros` WRITE;
/*!40000 ALTER TABLE `tRecursoRegistros` DISABLE KEYS */;
/*!40000 ALTER TABLE `tRecursoRegistros` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-27 14:26:43
